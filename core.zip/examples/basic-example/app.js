/* eslint-disable react/prefer-stateless-function */
import React, { Component } from 'react';

import styles from './stylesheets/app.scss';
import '../shared/favicon/favicon.ico';

class App extends Component {
  render() {
    return <div>HI</div>;
  }
}

export default App;
