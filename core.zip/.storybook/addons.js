/* eslint-disable import/no-extraneous-dependencies */
import '@storybook/addon-options/register';
import '@storybook/addon-notes/register';
import '@storybook/addon-actions/register';
import '@storybook/addon-notes/register';
